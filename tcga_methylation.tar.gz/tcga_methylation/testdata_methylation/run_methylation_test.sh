#!/bin/sh
awk -f ../scan_tcga_methylation.awk tcga_dir="methylation_testdata" barcode_file="test_barcodes.txt" genename_field=4 test_chr_locs.txt
exit
