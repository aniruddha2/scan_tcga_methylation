		    TCGA methylation data scanning

This directory contains the following:

scan_tcga_methylation.awk     - script to perform tcga scans
scan_tcga_methylation_doc.pdf - documentation
testdata_methylation          - directory of test data
README.txt                    - this file

Extensive documentation of the script requirements, options and usage
are in the pdf file.

In order to try the test data execute the following from this
directory:

cd testdata_methylation
./run_methylation_test.sh

The output should be written to the terminal.  Allow some time for the
run to complete since scanning for methylation over specified
chromosomal regions takes some processing.
